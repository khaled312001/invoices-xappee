export interface IChannel {
    _id: string;
    channel_id: number;
    name: string;
    type: string;
    enable: boolean;
  }
  