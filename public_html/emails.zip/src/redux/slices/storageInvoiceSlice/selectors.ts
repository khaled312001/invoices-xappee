import { State } from "@/redux/store";

export const selectStorageInvoiceSlice = (state: State) => state.storageInvoice;
