import { State } from "@/redux/store";

export const selectItemsSlice = (state:State) => state.item     