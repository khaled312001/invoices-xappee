export default function Footer() {
  return (
    <div className="flex justify-center items-center h-20 ">
        <p className="text-base opacity-80 cursor-auto select-none">© 2024 Xappee. All Rights Reserved.</p> 
    </div>
  )
}
